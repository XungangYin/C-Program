#include "stone.h"

Stone::Stone()
{

}

QString Stone::getText(){

    switch (this->_type) {
    case CHE:
        return "车";
    case JIANG:
        return "将";
    case PAO:
        return "炮";
    case MA:
        return "马";
    case BING:
        return "兵";
    case XIANG:
        return "相";
    case SHI:
        return "士";
    default:
        return "错误";
    }
}
void Stone::init(int id){
    _id = id;
    _dead = false;
    _red = id <16; //前16个为红方

    if(id < 16){
        _row = pos[id].row;
        _col = pos[id].col;
        _type = pos[id].type;
    }else{
        _row = 9 - pos[id-16].row;
        _col = 8 - pos[id-16].col;
        _type = pos[id-16].type;
    }
}
